# MazeBot
Arduino Uno based automated maze solving robot.  

Built by Miasya Bulger and Charles Zhang as the Grade 12 Computer Science summative project.  
Documentation and wiring diagrams can be found here: https://charlesyz.github.io/pdfs/mazebot.pdf.  
Termite not my creation, and is used as a COM controller. It displays the mapped maze from the Arduino's data. Unfortunately, I could not use the default Arduino software as plugging the arduino in while the program is running disrups the port. A third party software was the only option.  
